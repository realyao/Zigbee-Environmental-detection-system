#include "OSAL.h"
#include "ZGlobals.h"
#include "AF.h"
#include "aps_groups.h"
#include "ZDApp.h"

#include "E_SampleApp.h"
#include "SampleAppHw.h"

#include "OnBoard.h"

/* HAL */
#include "hal_lcd.h"
#include "hal_led.h"
#include "hal_key.h"

/* Define */
#include "AM2321.h"
#include "usart.h"
#include "ADC.h"
#include <stdlib.h>
#include <string.h>
#include "cmd.h"
#include "Relay.h"
#include <string.h>
#include "network.h"


// This list should be filled with Application specific Cluster IDs.
const cId_t SampleApp_ClusterList[SAMPLEAPP_MAX_CLUSTERS] =
{
  SAMPLEAPP_PERIODIC_CLUSTERID,
  SAMPLEAPP_FLASH_CLUSTERID
};

const SimpleDescriptionFormat_t SampleApp_SimpleDesc =
{
  SAMPLEAPP_ENDPOINT,              //  int Endpoint;
  SAMPLEAPP_PROFID,                //  uint16 AppProfId[2];
  SAMPLEAPP_DEVICEID,              //  uint16 AppDeviceId[2];
  SAMPLEAPP_DEVICE_VERSION,        //  int   AppDevVer:4;
  SAMPLEAPP_FLAGS,                 //  int   AppFlags:4;
  SAMPLEAPP_MAX_CLUSTERS,          //  uint8  AppNumInClusters;
  (cId_t *)SampleApp_ClusterList,  //  uint8 *pAppInClusterList;
  SAMPLEAPP_MAX_CLUSTERS,          //  uint8  AppNumInClusters;
  (cId_t *)SampleApp_ClusterList   //  uint8 *pAppInClusterList;
};

endPointDesc_t SampleApp_epDesc;

uint8 SampleApp_TaskID;   // Task ID for internal task/event processing
                          // This variable will be received when
                          // SampleApp_Init() is called.
devStates_t SampleApp_NwkState;

uint8 SampleApp_TransID;  // This is the unique message ID (counter)

afAddrType_t SampleApp_Periodic_DstAddr;
afAddrType_t SampleApp_Flash_DstAddr;

aps_Group_t SampleApp_Group; 

uint8 SampleAppPeriodicCounter = 0;
uint8 SampleAppFlashCounter = 0;

/*********************************************************************
 * LOCAL FUNCTIONS
 */
void SampleApp_HandleKeys( uint8 shift, uint8 keys );
void SampleApp_MessageMSGCB( afIncomingMSGPacket_t *pckt );
void SampleApp_SendPeriodicMessage( void );
void SampleApp_SendFlashMessage( uint16 flashTime );

void getOneData(uint8 data_type);
void getAllData(void);
void getNetwork(void);

extern unsigned char Am2321_Data[5];
int statue = 1;

/*-----------------------------------------------------------------------*/
//���巢���豸��Ϣ�ĺ���
void SendInfo(void);
//������ת16�����ַ���
void To_String(uint8 *dest, uint8 *src, uint8 length);

/*-----------------------------------------------------------------------*/
void SendInfo(void)
{
  RFTX rftx;
  uint16 nwk;
  //������նˣ����ͼ�¼ΪEND
  if(SampleApp_NwkState == DEV_END_DEVICE)
  {
    osal_memcpy(rftx.type,"END",3);
  }
  //�����·���������ͼ�¼ΪROU
  if(SampleApp_NwkState == DEV_ROUTER)
  {
    osal_memcpy(rftx.type,"ROU",3);
  }
  //�õ����������ַ
  nwk = NLME_GetShortAddr();
  To_String(rftx.myNWK,(uint8*)&nwk,2);
  HalUARTWrite(0,"myNWK:",6);   //�������
  HalUARTWrite(0,rftx.myNWK,4);
  HalUARTWrite(0,"\n",1);
  
  //�õ����ڵ�������ַ
  nwk = NLME_GetCoordShortAddr();
  To_String(rftx.pNWK,(uint8*)&nwk,2);
  HalUARTWrite(0,"pNWK:",5);   //�������
  HalUARTWrite(0,rftx.pNWK,4);
  HalUARTWrite(0,"\n",1);
  
  //�������ݸ�Э����
  if ( AF_DataRequest( &SampleApp_Periodic_DstAddr, &SampleApp_epDesc,
                       SAMPLEAPP_Network,
                       11,
                       (uint8 *)&rftx,
                       &SampleApp_TransID,
                       AF_DISCV_ROUTE, AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
  {
    // Successfully requested to be sent.
  }
  else
  {
    // Error occurred in request to send.
  }
  
}

//������ת16�����ַ����ĺ���
void To_String(uint8 *dest, uint8 *src, uint8 length)
{
  uint8 *xad;
  uint8 i = 0;
  uint8 ch;
  xad = src + length - 1;
  for(i = 0; i< length; i++,xad--)
  {
    ch = (*xad >> 4) & 0x0f;
    dest[i<<1] = ch + ((ch<10)?'0':'7');
    ch = *xad & 0x0f;
    dest[(i<<1)+1] = ch + ((ch<10)?'0':'7');
  }
}
/*-----------------------------------------------------------------------*/



void getOneData(uint8 data_type)
{
  char str[128] = {0};
  memset(str,0,sizeof(str));
  switch(data_type)
  {
  case CMD_Temperature:
      unsigned int Tem;
      Read_Sensor();
      Tem = Am2321_Data[2];
      Tem = Tem<<8;
      Tem |= Am2321_Data[3];
      sprintf(str,"%c%c%c Tem:%d",ID_Temperature,Frequency_c,CMD_Temperature,Tem);
      if ( AF_DataRequest( &SampleApp_Periodic_DstAddr, &SampleApp_epDesc,
                       SAMPLEAPP_PERIODIC_CLUSTERID,
                       strlen(str),
                       (uint8*)&str,
                       &SampleApp_TransID,
                       AF_DISCV_ROUTE,
                       AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
      {
      }
      else
      {
        // Error occurred in request to send.
      }
      break;
  case CMD_Humidity:
      unsigned int Humidity;
      Read_Sensor();
      Humidity = Am2321_Data[0];
      Humidity = Humidity<<8;
      Humidity |= Am2321_Data[1];
      sprintf(str,"%c%c%c Humidity:%d",ID_Humidity,CMD_Humidity,Frequency_c,Humidity);
      if ( AF_DataRequest( &SampleApp_Periodic_DstAddr, &SampleApp_epDesc,
                       SAMPLEAPP_PERIODIC_CLUSTERID,
                       strlen(str),
                       (uint8*)&str,
                       &SampleApp_TransID,
                       AF_DISCV_ROUTE,
                       AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
      {
      }
      else
      {
        // Error occurred in request to send.
      }
      break;
  case CMD_Brightness:
      unsigned int Brightness = ReadLightData();
      sprintf(str,"%c%c%c Brightness:%d",ID_Brightness,CMD_Brightness,Frequency_c,Brightness);
      if ( AF_DataRequest( &SampleApp_Periodic_DstAddr, &SampleApp_epDesc,
                       SAMPLEAPP_PERIODIC_CLUSTERID,
                       strlen(str),
                       (uint8*)&str,
                       &SampleApp_TransID,
                       AF_DISCV_ROUTE,
                       AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
      {
      }
      else
      {
        // Error occurred in request to send.
      }
      break;
#ifdef _RELAY_H
  case CMD_Relay:
      if(statue)
      {
        Relay_Open(2);
        statue = 0;
        sprintf(str,"%c%c%c Relay:open",ID_Relay,CMD_Relay,Frequency_c);
        if ( AF_DataRequest( &SampleApp_Periodic_DstAddr, &SampleApp_epDesc,
                           SAMPLEAPP_PERIODIC_CLUSTERID,
                           strlen(str),
                           (uint8*)&str,
                           &SampleApp_TransID,
                           AF_DISCV_ROUTE,
                           AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
         {}
         else{}
      }
      else
      {
        Relay_Close(2);
        statue = 1;
        sprintf(str,"%c%c%c Relay:close",ID_Relay,CMD_Relay,Frequency_c);
        if ( AF_DataRequest( &SampleApp_Periodic_DstAddr, &SampleApp_epDesc,
                           SAMPLEAPP_PERIODIC_CLUSTERID,
                           strlen(str),
                           (uint8*)&str,
                           &SampleApp_TransID,
                           AF_DISCV_ROUTE,
                           AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
         {}
         else{}
      }
      break;
#endif
  case CMD_Noise:
      break;
  default:HalUARTWrite(0,"Not Type/n",9);
  }
  memset(str,0,sizeof(str));
}
void getAllData(void)
{
  SampleApp_SendPeriodicMessage();
}
void getNetwork(void)
{
      char str[] = {"network"};
      if ( AF_DataRequest( &SampleApp_Periodic_DstAddr, &SampleApp_epDesc,
                       SAMPLEAPP_PERIODIC_CLUSTERID,
                       strlen(str),
                       (uint8*)&str,
                       &SampleApp_TransID,
                       AF_DISCV_ROUTE,
                       AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
      {
      }
      else
      {
        // Error occurred in request to send.
      }
}


void SampleApp_Init( uint8 task_id )
{
  SampleApp_TaskID = task_id;
  SampleApp_NwkState = DEV_INIT;
  SampleApp_TransID = 0;
  
#ifdef _RELAY_H
  Relay_Init();
#endif
  AM2321_Init();

 #if defined ( BUILD_ALL_DEVICES )
  // The "Demo" target is setup to have BUILD_ALL_DEVICES and HOLD_AUTO_START
  // We are looking at a jumper (defined in SampleAppHw.c) to be jumpered
  // together - if they are - we will start up a coordinator. Otherwise,
  // the device will start as a router.
  if ( readCoordinatorJumper() )
    zgDeviceLogicalType = ZG_DEVICETYPE_COORDINATOR;
  else
    zgDeviceLogicalType = ZG_DEVICETYPE_ROUTER;
#endif // BUILD_ALL_DEVICES

#if defined ( HOLD_AUTO_START )
  // HOLD_AUTO_START is a compile option that will surpress ZDApp
  //  from starting the device and wait for the application to
  //  start the device.
  ZDOInitDevice(0);
#endif

  // Setup for the periodic message's destination address
  // Broadcast to everyone
  SampleApp_Periodic_DstAddr.addrMode = (afAddrMode_t)Addr16Bit;
  SampleApp_Periodic_DstAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_Periodic_DstAddr.addr.shortAddr = 0x0000;

  // Setup for the flash command's destination address - Group 1
  SampleApp_Flash_DstAddr.addrMode = (afAddrMode_t)afAddrGroup;
  SampleApp_Flash_DstAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_Flash_DstAddr.addr.shortAddr = SAMPLEAPP_FLASH_GROUP;

  // Fill out the endpoint description.
  SampleApp_epDesc.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_epDesc.task_id = &SampleApp_TaskID;
  SampleApp_epDesc.simpleDesc
            = (SimpleDescriptionFormat_t *)&SampleApp_SimpleDesc;
  SampleApp_epDesc.latencyReq = noLatencyReqs;

  // Register the endpoint description with the AF
  afRegister( &SampleApp_epDesc );

  // Register for all key events - This app will handle all key events
  RegisterForKeys( SampleApp_TaskID );

  // By default, all devices start out in Group 1
  SampleApp_Group.ID = 0x0001;
  osal_memcpy( SampleApp_Group.name, "Group 1", 7  );
  aps_AddGroup( SAMPLEAPP_ENDPOINT, &SampleApp_Group );

#if defined ( LCD_SUPPORTED )
  HalLcdWriteString( "SampleApp", HAL_LCD_LINE_1 );
#endif
}

/*********************************************************************
 * @fn      SampleApp_ProcessEvent
 *
 * @brief   Generic Application Task event processor.  This function
 *          is called to process all events for the task.  Events
 *          include timers, messages and any other user defined events.
 *
 * @param   task_id  - The OSAL assigned task ID.
 * @param   events - events to process.  This is a bit map and can
 *                   contain more than one event.
 *
 * @return  none
 */
uint16 SampleApp_ProcessEvent( uint8 task_id, uint16 events )
{
  afIncomingMSGPacket_t *MSGpkt;
  (void)task_id;  // Intentionally unreferenced parameter

  if ( events & SYS_EVENT_MSG )
  {
    MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( SampleApp_TaskID );
    while ( MSGpkt )
    {
      switch ( MSGpkt->hdr.event )
      {
        // Received when a key is pressed
        case KEY_CHANGE:
          SampleApp_HandleKeys( ((keyChange_t *)MSGpkt)->state, ((keyChange_t *)MSGpkt)->keys );
          break;

        // Received when a messages is received (OTA) for this endpoint
        case AF_INCOMING_MSG_CMD:
          SampleApp_MessageMSGCB( MSGpkt );
          break;

        // Received whenever the device changes state in the network
        case ZDO_STATE_CHANGE:
          SampleApp_NwkState = (devStates_t)(MSGpkt->hdr.status);
          if ( (SampleApp_NwkState == DEV_ZB_COORD)
              || (SampleApp_NwkState == DEV_ROUTER)
              || (SampleApp_NwkState == DEV_END_DEVICE) )
          {
            // Start sending the periodic message in a regular interval.
            osal_start_timerEx( SampleApp_TaskID,
                              SAMPLEAPP_SEND_PERIODIC_MSG_EVT,
                              SAMPLEAPP_SEND_PERIODIC_MSG_TIMEOUT );
          }
          else
          {
            // Device is no longer in the network
          }
          break;

        default:
          break;
      }

      // Release the memory
      osal_msg_deallocate( (uint8 *)MSGpkt );

      // Next - if one is available
      MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( SampleApp_TaskID );
    }

    // return unprocessed events
    return (events ^ SYS_EVENT_MSG);
  }

  // Send a message out - This event is generated by a timer
  //  (setup in SampleApp_Init()).
  if ( events & SAMPLEAPP_SEND_PERIODIC_MSG_EVT )
  {
    // Send the periodic message
    SampleApp_SendPeriodicMessage();

    // Setup to send message again in normal period (+ a little jitter)
    osal_start_timerEx( SampleApp_TaskID, SAMPLEAPP_SEND_PERIODIC_MSG_EVT,
        (SAMPLEAPP_SEND_PERIODIC_MSG_TIMEOUT) );
    HalLedBlink( HAL_LED_1, 2, 50, 300 );

    // return unprocessed events
    return (events ^ SAMPLEAPP_SEND_PERIODIC_MSG_EVT);
  }

/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
  return 0;
}

/*********************************************************************
 * Event Generation Functions
 */
/*********************************************************************
 * @fn      SampleApp_HandleKeys
 *
 * @brief   Handles all key events for this device.
 *
 * @param   shift - true if in shift/alt.
 * @param   keys - bit field for key events. Valid entries:
 *                 HAL_KEY_SW_2
 *                 HAL_KEY_SW_1
 *
 * @return  none
 */
void SampleApp_HandleKeys( uint8 shift, uint8 keys )
{
  (void)shift;  // Intentionally unreferenced parameter
  
  if ( keys & HAL_KEY_SW_1 )
  {
    /* This key sends the Flash Command is sent to Group 1.
     * This device will not receive the Flash Command from this
     * device (even if it belongs to group 1).
     */
    SampleApp_SendFlashMessage( SAMPLEAPP_FLASH_DURATION );
  }

  if ( keys & HAL_KEY_SW_2 )
  {
    /* The Flashr Command is sent to Group 1.
     * This key toggles this device in and out of group 1.
     * If this device doesn't belong to group 1, this application
     * will not receive the Flash command sent to group 1.
     */
    aps_Group_t *grp;
    grp = aps_FindGroup( SAMPLEAPP_ENDPOINT, SAMPLEAPP_FLASH_GROUP );
    if ( grp )
    {
      // Remove from the group
      aps_RemoveGroup( SAMPLEAPP_ENDPOINT, SAMPLEAPP_FLASH_GROUP );
    }
    else
    {
      // Add to the flash group
      aps_AddGroup( SAMPLEAPP_ENDPOINT, &SampleApp_Group );
    }
  }
}

/*********************************************************************
 * LOCAL FUNCTIONS
 */

/*********************************************************************
 * @fn      SampleApp_MessageMSGCB
 *
 * @brief   Data message processor callback.  This function processes
 *          any incoming data - probably from other devices.  So, based
 *          on cluster ID, perform the intended action.
 *
 * @param   none
 *
 * @return  none
 */
void SampleApp_MessageMSGCB( afIncomingMSGPacket_t *pkt )
{
      uint8 *data = pkt->cmd.Data;
      uint8 cmd_type;
      //��֤��>CMD<
      if(data[0]==CMD_DATA_START && data[3] == CMD_DATA_END)
      {
        //��һ���ֽ�����������
        cmd_type = data[1];
        switch(cmd_type)
        {
          case CMD_GET_ONE_DATA:  getOneData(data[2]);break;
          case CMD_GET_ALL_DATA:  getAllData();break;
          case CMD_GET_NETWORK:   getNetwork();break;
          default:HalUARTWrite(0,"Not CMD!\n",9);         
        }
      }
}

/*********************************************************************
 * @fn      SampleApp_SendPeriodicMessage
 *
 * @brief   Send the periodic message.
 *
 * @param   none
 *
 * @return  none
 */
extern unsigned char Am2321_Data[5];
void SampleApp_SendPeriodicMessage( void )
{
  char str[128] = {0};
  unsigned int Light = ReadLightData();	
  unsigned int Humidity;
  unsigned int Tem;
  
  Read_Sensor();
  Humidity = Am2321_Data[0];
  Humidity = Humidity<<8;
  Humidity |= Am2321_Data[1];
  
  Tem = Am2321_Data[2];
  Tem = Tem<<8;
  Tem |= Am2321_Data[3];
  
  sprintf(str,"L:%d",Light);
  sprintf(str+strlen(str),"H:%d",Humidity);
  sprintf(str+strlen(str),"T:%d",Tem);
  HalUARTWrite(0,str,strlen(str));
  if ( AF_DataRequest( &SampleApp_Periodic_DstAddr, &SampleApp_epDesc,
                       SAMPLEAPP_PERIODIC_CLUSTERID,
                       strlen(str),
                       (uint8*)&str,
                       &SampleApp_TransID,
                       AF_DISCV_ROUTE,
                       AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
  {
  }
  else
  {
    // Error occurred in request to send.
  }
}

/*********************************************************************
 * @fn      SampleApp_SendFlashMessage
 *
 * @brief   Send the flash message to group 1.
 *
 * @param   flashTime - in milliseconds
 *
 * @return  none
 */
void SampleApp_SendFlashMessage( uint16 flashTime )
{
  uint8 buffer[3];
  buffer[0] = (uint8)(SampleAppFlashCounter++);
  buffer[1] = LO_UINT16( flashTime );
  buffer[2] = HI_UINT16( flashTime );

  if ( AF_DataRequest( &SampleApp_Flash_DstAddr, &SampleApp_epDesc,
                       SAMPLEAPP_FLASH_CLUSTERID,
                       3,
                       buffer,
                       &SampleApp_TransID,
                       AF_DISCV_ROUTE,
                       AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
  {
  }
  else
  {
    // Error occurred in request to send.
  }
}

/*********************************************************************
*********************************************************************/
