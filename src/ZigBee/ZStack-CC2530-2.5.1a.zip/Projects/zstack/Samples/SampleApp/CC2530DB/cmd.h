#ifndef _CMD_H
#define _CMD_H

typedef unsigned char uint8;

#define CMD_DATA_START	'>'
#define CMD_DATA_END	'<'

//pc->ZigBee Coor
#define CMD_GET_ONE_DATA	'0'
#define CMD_GET_ALL_DATA	'1'
#define CMD_GET_NETWORK		'2'
#define CMD_NULL_DATA		'3'
#define CMD_Temperature		'T'		//温度
#define CMD_Humidity		'H'		//湿度
#define CMD_Brightness		'B'		//亮度
#define CMD_Relay			'R'		//继电器
#define CMD_Noise			'N'		//噪声

//ZigBee_ID
#define ID_ALL				'0'
#define ID_Temperature		'1'
#define ID_Humidity			'2'
#define ID_Brightness		'3'
#define ID_Relay			'4'
#define ID_Noise			'5'

//频率
#define Frequency_10s	'0'		//10秒
#define Frequency_20s	'1'		//20秒
#define Frequency_30s	'2'		//30秒
#define Frequency_1h	'3'		//1小时
#define Frequency_2h	'4'		//2小时
#define Frequency_3h	'5'		//3小时
#define Frequency_1d	'6'		//1天
#define Frequency_c		'7'		//用户控制


#endif