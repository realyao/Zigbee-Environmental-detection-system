#include "network.h"

//定义一个RFTX组
RFTX info[RFTX_TABLE_LENGTH];
//数组个数记录
uint8 num = 0;

