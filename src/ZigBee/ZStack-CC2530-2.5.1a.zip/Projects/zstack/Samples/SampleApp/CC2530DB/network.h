#ifndef _NETWORK_H
#define _NETWORK_H

#include <string.h>
#include "OnBoard.h"

/*-------------------------------------------------------------------------------*/
//结构体声明
typedef struct RFTXBUF
{
  uint8 type[3];        //设备类型
  uint8 myNWK[4];       //网络地址
  uint8 pNWK[4];        //父节点网络地址
}RFTX;

//表格最大长度
#define RFTX_TABLE_LENGTH	10

//数据包标识
#define SAMPLEAPP_Network	0x1234

//串口命令
#define CMD_FROM_PC         "getNetwork"
#define cmd_len             strlen(CMD_FROM_PC)


//定义一个RFTX组
extern RFTX info[RFTX_TABLE_LENGTH];
//数组个数记录
extern uint8 num;



/*-----------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*/



#endif