#include "Relay.h"
#include "OnBoard.h"
#include "hal_uart.h"


void Relay_Init(void)
{
	P0SEL &= ~0xC1; 
	P0DIR |= 0xC1; 
	P0 &= ~0xC1;
}

void Relay_Open(int select)
{
	switch(select)
	{
		case 1:P0_0 = 1; HalUARTWrite(0,"1 open\n",7);break;//开H
		case 2:P0_6 = 1; HalUARTWrite(0,"2 open\n",7);break;//开
		case 3:P0_7 = 1; HalUARTWrite(0,"3 open\n",7);break;//开
		default:break;
	}
}

void Relay_Close(int select)
{
	switch(select)
	{
		case 1:P0_0 = 0; HalUARTWrite(0,"1 close\n",8);break;//关
		case 2:P0_6 = 0; HalUARTWrite(0,"2 close\n",8);break;//关
		case 3:P0_7 = 0; HalUARTWrite(0,"3 close\n",8);break;//关
                default:break;
	}	
}