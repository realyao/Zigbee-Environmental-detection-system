#ifndef _RELAY_H
#define _RELAY_H

#include "OnBoard.h"
#include "hal_uart.h"

void Relay_Init(void);
void Relay_Open(int select);
void Relay_Close(int select);


#endif